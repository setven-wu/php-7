I<?php

function addBook(int $id): void {
    $db = new PDO(
        'mysql:host=127.0.0.1;dbname=bookstore',
        'root',
        ''
    );

    $query = 'UPDATE book SET stock = stock + 1 WHERE id = :id';
    $statement = $db->prepare($query);
    $statement->bindValue('id', $id);
    if (!$statement->execute()) {
        throw new Exception($statement->errorInfo()[2]);
    }
}