<?php

$rows = $db->query('SELECT * FROM book ORDER BY title');
foreach ($rows as $row) {
    var_dump($row);
}
$result = $db->exec($query);
var_dump($result); // 1

$result = $db->exec($query);
var_dump($result); // false
var_dump($db->errorInfo()[2]); // Duplicate entry '9788187981954' for key 'isbn'