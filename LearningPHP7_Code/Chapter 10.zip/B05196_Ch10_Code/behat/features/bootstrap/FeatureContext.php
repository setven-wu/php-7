<?php

use Behat\Behat\Context\Context;
use Behat\Behat\Context\SnippetAcceptingContext;
use Behat\Gherkin\Node\PyStringNode;
use Behat\Gherkin\Node\TableNode;

require_once __DIR__ . '/../../vendor/phpunit/phpunit/src/Framework/Assert/Functions.php';

class FeatureContext implements Context, SnippetAcceptingContext
{
    private $db;
    private $config;
    private $output;

    public function __construct() {
        $configFileContent = file_get_contents(__DIR__ . '/../../config/app.json');
        $this->config = json_decode($configFileContent, true);
    }

    /**
     * @BeforeScenario
     */
    public function before($event) {
        $this->executeQuery('DROP SCHEMA IF EXISTS bdd_db_test');
        exec('rm db/migrations/*.sql > /dev/null 2>&1');
    }

    private function getDb(): PDO {
        if ($this->db === null) {
            $this->db = new PDO(
                "mysql:host=127.0.0.1;dbname=bdd_db_test",
                'root',
                'root'
            );
        }

        return $this->db;
    }

    /**
     * @When I run the migrations script
     */
    public function iRunTheMigrationsScript() {
        exec('php migrate.php', $this->output);
    }

    /**
     * @Then I should have an empty migrations table
     */
    public function iShouldHaveAnEmptyMigrationsTable() {
        $migrations = $this->getDb()->query('SELECT * FROM migrations')->fetch();
        assertEmpty($migrations);
    }

    /**
     * @Then I should get:
     */
    public function iShouldGet(PyStringNode $string) {
        assertEquals(implode("\n", $this->output), $string->getRaw());
    }

    /**
    * @Given I have the bdd_db_test
    */
    public function iHaveTheBddDbTest() {
        $this->executeQuery('CREATE SCHEMA bdd_db_test');
    }

    /**
     * @Given I have migration :version
     */
    public function iHaveMigration(string $version) {
        $this->getDb()->exec(file_get_contents(__DIR__ . '/../../db/setup.sql'));

        $query = <<<SQL
    INSERT INTO migrations (version, status)
    VALUES(:version, 'success')
SQL;
        $this->getDb()->prepare($query)->execute(['version' => $version]);
    }

    /**
     * @Given I have migration file :version:
     */
    public function iHaveMigrationFile(string $version, PyStringNode $file) {
        $filePath = __DIR__ . "/../../db/migrations/$version.sql";
        file_put_contents($filePath, $file->getRaw());
    }

    /**
     * @Then I should only have the following tables:
     */
    public function iShouldOnlyHaveTheFollowingTables(TableNode $tables) {
        $tablesInDb = $this->getDb()
            ->query('SHOW TABLES')
            ->fetchAll(PDO::FETCH_NUM);

        assertEquals($tablesInDb, array_values($tables->getRows()));
    }

    /**
     * @Then I should have the following migrations:
     */
    public function iShouldHaveTheFollowingMigrations(TableNode $migrations) {
        $query = 'SELECT version, status FROM migrations';
        $migrationsInDb = $this->getDb()->query($query)->fetchAll(PDO::FETCH_NUM);

        assertEquals($migrations->getRows(), $migrationsInDb);
    }

    private function executeQuery(string $query) {
        $removeSchemaCommand = sprintf(
            'mysql -u %s -p%s %s -h %s -e "%s"',
            $this->config['user'],
            $this->config['password'],
            empty($this->config['password'])
                ? '' : "-p{$this->config['password']}",
            $this->config['host'],
            $query
        );

        exec($removeSchemaCommand);
    }
}
