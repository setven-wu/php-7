<?php

namespace Bookstore\Exceptions;

use Exception;

class NotFoundException extends Exception {
}