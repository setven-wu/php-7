<?php

namespace Bookstore\Tests;

use Bookstore\Domain\Book;
use PHPUnit_Framework_TestCase;
use InvalidArgumentException;
use ReflectionClass;

abstract class AbstractTestCase extends PHPUnit_Framework_TestCase {
    protected function mock(string $className) {
        if (strpos($className, '\\') !== 0) {
            $className = '\\' . $className;
        }

        if (!class_exists($className)) {
            $className = '\Bookstore\\' . trim($className, '\\');

            if (!class_exists($className)) {
                throw new InvalidArgumentException(
                    "Class $className not found."
                );
            }
        }

        return $this->getMockBuilder($className)
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function buildBook(array $properties): Book {
        $book = new Book();
        $reflectionClass = new ReflectionClass(Book::class);

        foreach ($properties as $key => $value) {
            $property = $reflectionClass->getProperty($key);
            $property->setAccessible(true);
            $property->setValue($book, $value);
        }

        return $book;
    }
}
