<?php

namespace Bookstore\Exceptions;

use Exception;

class DbException extends Exception {
}